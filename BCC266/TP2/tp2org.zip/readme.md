Como compilar?
Apenas digite "make" no terminal

Como rodar?
Linha de execucao: ./exe TIPO_INSTRUCAO [TAMANHO_RAM|ARQUIVO_DE_INSTRUCOES] TAMANHO_L1 TAMANHO_L2 TAMANHO_L3
Exemplo 1 de execucao: ./exe random 10 2 4 8
Exemplo 2 de execucao: ./exe file arquivo_de_instrucoes.txt