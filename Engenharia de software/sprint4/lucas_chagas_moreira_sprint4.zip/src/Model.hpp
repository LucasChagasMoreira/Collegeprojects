#ifndef MODEL_HPP
    #define MODEL_HPP

    #include <cstring>
    #include <ostream>
    #include <vector>
    
    #include "Flow.hpp"
    #include "System.hpp"

    /// A Model is what integrates flows and systems.
    ///
    /// By creating a model, you can run() simulations.
    class Model
    {   
        public:
            virtual ~Model() {}

            typedef typename vector<Flow *>::iterator itFlow; // alterar pra impl?
            typedef typename vector<System *>::iterator itSystem;

            virtual string getName() const = 0;
            virtual void setName(const string name) = 0;

            virtual itFlow getFlowBegin() = 0;
            virtual itFlow getFlowEnd() = 0;
            virtual int getFlowSize() = 0;

            virtual itSystem getSystemBegin() = 0;
            virtual itSystem getSystemEnd() = 0;
            virtual int getSystemSize() = 0;

            virtual void add(System *) = 0;
            virtual void add(Flow *) = 0;
            virtual bool remove(System *) = 0;
            virtual bool remove(Flow *) = 0;
            virtual void clear() = 0;
            virtual void show() = 0;

            /// @brief Run a model simulation by passing the time information.
            /// @param ini_time  Initial time.
            /// @param fin_time  Final time.
            virtual void run(int, int) = 0;
    };
#endif
