#ifndef SYSTEM_HPP
    #define SYSTEM_HPP

    #include <string>
    #include <ostream>

    using namespace std;

    /// @brief A System is a stock of energy.
    class System
    {
        public:
            virtual ~System() {}
            
            virtual System &operator=(const System &obj) = 0;

            virtual string getName() const = 0;
            virtual void setName(const string name) = 0;
            virtual double getValue() const = 0;
            virtual void setValue(double value) = 0;
    };
#endif