var searchData=
[
  ['add_67',['add',['../class_model.html#a70362afdd9db6268b4adaedfeddb2935',1,'Model::add(System *)=0'],['../class_model.html#ac1e19f5fcc4ced9defbfe2847a26ff33',1,'Model::add(Flow *)=0'],['../class_model___impl.html#a967fde3820a87afeb995e57f7aefed1a',1,'Model_Impl::add(System *)'],['../class_model___impl.html#a54eeea5ad2f5fc56c81c669d19676661',1,'Model_Impl::add(Flow *)']]]
];
