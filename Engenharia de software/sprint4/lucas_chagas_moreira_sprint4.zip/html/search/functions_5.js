var searchData=
[
  ['model_5fimpl_81',['Model_Impl',['../class_model___impl.html#ac6abb0dc676d69986f1217672753e12a',1,'Model_Impl::Model_Impl()'],['../class_model___impl.html#a7b7d074730157ec65a138c5b7b69d55f',1,'Model_Impl::Model_Impl(const string name)'],['../class_model___impl.html#aa056b89cfb198423d0f867873071fc97',1,'Model_Impl::Model_Impl(Model &amp;obj)']]]
];
