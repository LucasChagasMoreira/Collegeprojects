var searchData=
[
  ['logisflow_89',['LogisFlow',['../class_logis_flow.html#a079225e2f70c753557365cd634ef664d',1,'LogisFlow']]],
  ['logisticalfuncionaltest_90',['logisticalFuncionalTest',['../funcionaltests_8cpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcionaltests.cpp'],['../funcionaltests_8hpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcionaltests.cpp']]]
];
