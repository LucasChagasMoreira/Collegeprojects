var class_system =
[
    [ "System", "class_system.html#ae317936c9bcf1374d61745572e0f2f8a", null ],
    [ "~System", "class_system.html#a3be70bb338e3f062f821173fd15680d0", null ],
    [ "System", "class_system.html#a041fbf29646a27026fec21c93dbba105", null ],
    [ "System", "class_system.html#ad3b5426a629c54eecbfe46b687100fb2", null ],
    [ "System", "class_system.html#a37ee8dd62c5257c4be44406074ea2115", null ],
    [ "System", "class_system.html#ae85f88a65a564ff9b3308b05d8fd1fa2", null ],
    [ "getName", "class_system.html#a47ece132a04247cd74aea11537830bd4", null ],
    [ "getValue", "class_system.html#aa7d17369d1034e7d8643a63f69d1901d", null ],
    [ "operator=", "class_system.html#a93f350faa6efd0b1eca2bfc2c73c8cd6", null ],
    [ "setName", "class_system.html#a36e1f259c6de9329eff42ce671ea80fa", null ],
    [ "setValue", "class_system.html#a5343de0a45485edd88bc87f338fe9a19", null ],
    [ "name", "class_system.html#a29fe2868c0d56fdebc67f1bef5d5cca3", null ],
    [ "value", "class_system.html#a879687b1125ef20757c2a61345fedd00", null ]
];