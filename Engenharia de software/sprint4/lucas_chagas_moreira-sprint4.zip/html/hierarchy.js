var hierarchy =
[
    [ "Flow", "class_flow.html", [
      [ "Flow_Impl", "class_flow___impl.html", [
        [ "Exponential_Flow", "class_exponential___flow.html", null ],
        [ "Exponential_Flow", "class_exponential___flow.html", null ],
        [ "Logistic_Flow", "class_logistic___flow.html", null ],
        [ "Logistic_Flow", "class_logistic___flow.html", null ]
      ] ]
    ] ],
    [ "Model", "class_model.html", [
      [ "Model_Impl", "class_model___impl.html", null ]
    ] ],
    [ "System", "class_system.html", [
      [ "System_Impl", "class_system___impl.html", null ]
    ] ]
];