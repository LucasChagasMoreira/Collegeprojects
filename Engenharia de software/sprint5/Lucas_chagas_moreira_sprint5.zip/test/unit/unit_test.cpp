#include "unit_test.hpp"

void run_unit_tests_globals()
{
    // no global functions
    return;
}