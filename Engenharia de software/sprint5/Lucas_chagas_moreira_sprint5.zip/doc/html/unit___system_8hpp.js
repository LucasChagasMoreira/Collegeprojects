var unit___system_8hpp =
[
    [ "run_unit_test_System", "unit___system_8hpp.html#a508d8501edd77719732fca2f7985d316", null ],
    [ "unit_System_constructor", "unit___system_8hpp.html#a6a39fd054412469cd77649218d3ecceb", null ],
    [ "unit_System_destructor", "unit___system_8hpp.html#a021603784a12638ed34bc8690c832dfc", null ],
    [ "unit_System_getName", "unit___system_8hpp.html#a672a51794472bbde676a33115e003b15", null ],
    [ "unit_System_getValue", "unit___system_8hpp.html#ab320622db511f54344c510a9cfdbff94", null ],
    [ "unit_System_setName", "unit___system_8hpp.html#a470f565c55f643e387d5cc7005cab1ea", null ],
    [ "unit_System_setValue", "unit___system_8hpp.html#ac322ab5fd0cd1051b54ffab7177032e6", null ]
];