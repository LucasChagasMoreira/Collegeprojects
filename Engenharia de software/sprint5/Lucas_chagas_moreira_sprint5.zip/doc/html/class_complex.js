var class_complex =
[
    [ "Complex", "class_complex.html#a6d8b4b7dceb6a37cb841c4f3b72a03d1", null ],
    [ "execute", "class_complex.html#a2a9ff0d9a9b5054a1489d17984fdfb76", null ]
];