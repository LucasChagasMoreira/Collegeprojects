var funcional__tests_8cpp =
[
    [ "complexFuncionalTest", "funcional__tests_8cpp.html#a943dfe0c597a01c9760c140715fed527", null ],
    [ "exponentialFuncionalTest", "funcional__tests_8cpp.html#a2c448ffaffdff4b03c825a01dffa6f27", null ],
    [ "logisticalFuncionalTest", "funcional__tests_8cpp.html#a60914db64bde71b56d69320797266c29", null ]
];