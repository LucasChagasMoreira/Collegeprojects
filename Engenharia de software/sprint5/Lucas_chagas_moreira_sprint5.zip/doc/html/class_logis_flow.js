var class_logis_flow =
[
    [ "LogisFlow", "class_logis_flow.html#a079225e2f70c753557365cd634ef664d", null ],
    [ "execute", "class_logis_flow.html#a02ae51c6da18f4f5dc0700fcab79b3d8", null ]
];