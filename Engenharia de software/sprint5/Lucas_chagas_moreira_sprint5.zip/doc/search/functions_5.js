var searchData=
[
  ['model_66',['Model',['../class_model.html#ae3b375de5f6df4faf74a95d64748e048',1,'Model::Model()'],['../class_model.html#a522300eb06394ff3c35e5f1f0b74525d',1,'Model::Model(const string name)'],['../class_model.html#ac00568179c3d466977eb67c0993cbbcf',1,'Model::Model(const Model &amp;obj)']]]
];
