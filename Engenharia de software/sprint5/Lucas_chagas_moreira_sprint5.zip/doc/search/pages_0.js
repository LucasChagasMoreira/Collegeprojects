var searchData=
[
  ['and_20examples_88',['and Examples',['../_summary.html',1,'']]]
];
