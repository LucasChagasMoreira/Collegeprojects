var searchData=
[
  ['add_52',['add',['../class_model.html#ae4d749689ba490e2a74d64bb10721a94',1,'Model::add(System *)'],['../class_model.html#a94757709637014384aa155189ada81e4',1,'Model::add(Flow *)']]]
];
