var searchData=
[
  ['debuging_293',['DEBUGING',['../funcional__tests_8cpp.html#aeff79046387df0de04e7de11061a704b',1,'DEBUGING():&#160;funcional_tests.cpp'],['../unit___handle_body_8cpp.html#aeff79046387df0de04e7de11061a704b',1,'DEBUGING():&#160;unit_HandleBody.cpp']]]
];
