var searchData=
[
  ['pimpl_5f_68',['pImpl_',['../class_handle.html#a16021e57596d7369dfa1a9fadc35c06f',1,'Handle']]]
];
