var class_system =
[
    [ "~System", "class_system.html#a2fc0f34023977cab9b628aa9f734d88c", null ],
    [ "getName", "class_system.html#ab4f23c21832d6bbef462a5a20b296912", null ],
    [ "getValue", "class_system.html#a41b673faa6c199eb8e4f204639fab4f2", null ],
    [ "operator=", "class_system.html#af69cdea4a2a5deb4cc1d3652072a7772", null ],
    [ "setName", "class_system.html#a3108cd4b50d2ac81daa100b627c3b188", null ],
    [ "setValue", "class_system.html#a7421d2e6970a0c4169a2febe254f2060", null ]
];