var class_body =
[
    [ "Body", "class_body.html#a7727b0d8c998bbc2942e4c802e31e2eb", null ],
    [ "~Body", "class_body.html#a9b15e54cf881ac0ca64790ca1d50110e", null ],
    [ "attach", "class_body.html#a5d53322c76a6952d096cb7564ac86db1", null ],
    [ "detach", "class_body.html#ad481d0c8368db318795c9a0a8fdd3717", null ],
    [ "refCount", "class_body.html#a59ae961812625b8636071ba61b1a75fc", null ]
];