var hierarchy =
[
    [ "Body", "class_body.html", [
      [ "Flow_Impl", "class_flow___impl.html", [
        [ "Complex", "class_complex.html", null ],
        [ "Exponential_Flow", "class_exponential___flow.html", null ],
        [ "Logistic_Flow", "class_logistic___flow.html", null ]
      ] ],
      [ "Model_Impl", "class_model___impl.html", null ],
      [ "System_Impl", "class_system___impl.html", null ]
    ] ],
    [ "Flow", "class_flow.html", [
      [ "FlowHandle< T >", "class_flow_handle.html", null ]
    ] ],
    [ "Handle< T >", "class_handle.html", [
      [ "FlowHandle< T >", "class_flow_handle.html", null ]
    ] ],
    [ "Handle< Model_Impl >", "class_handle.html", [
      [ "ModelHandle", "class_model_handle.html", null ]
    ] ],
    [ "Handle< System_Impl >", "class_handle.html", [
      [ "SystemHandle", "class_system_handle.html", null ]
    ] ],
    [ "Model", "class_model.html", [
      [ "ModelHandle", "class_model_handle.html", null ]
    ] ],
    [ "System", "class_system.html", [
      [ "SystemHandle", "class_system_handle.html", null ]
    ] ]
];