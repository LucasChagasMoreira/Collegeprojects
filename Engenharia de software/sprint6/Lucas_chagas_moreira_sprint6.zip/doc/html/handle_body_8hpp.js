var handle_body_8hpp =
[
    [ "Handle", "class_handle.html", "class_handle" ],
    [ "Body", "class_body.html", "class_body" ],
    [ "numBodyCreated", "handle_body_8hpp.html#ac1322042429ed9724fbef55908244f3b", null ],
    [ "numBodyDeleted", "handle_body_8hpp.html#aba38ebae7f83ef57afab8c447dddb6cf", null ],
    [ "numHandleCreated", "handle_body_8hpp.html#aac78cb29dfe4a565da68073b0beebf2f", null ],
    [ "numHandleDeleted", "handle_body_8hpp.html#a01128a06118f949a0b24a3d080f515fd", null ]
];