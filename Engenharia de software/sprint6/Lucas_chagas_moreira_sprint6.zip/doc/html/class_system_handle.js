var class_system_handle =
[
    [ "SystemHandle", "class_system_handle.html#a89a4db1dc76231a95167a904fd0175c4", null ],
    [ "SystemHandle", "class_system_handle.html#a6f445bd011f62d25bf24598c89112c6a", null ],
    [ "SystemHandle", "class_system_handle.html#afc6544a46a26a1662b166f41f592c9e7", null ],
    [ "SystemHandle", "class_system_handle.html#a9072026a1a6616231a185d5279c66265", null ],
    [ "SystemHandle", "class_system_handle.html#a362c9958cb2c5d7584af566d7a714b9c", null ],
    [ "getName", "class_system_handle.html#ae0e8c19df92e41d60f2156562fd2bd52", null ],
    [ "getValue", "class_system_handle.html#aeb69190853dc47d4c73ccd3928bfc3a1", null ],
    [ "operator=", "class_system_handle.html#ab867a2c03686b08e151841ebb1f351d3", null ],
    [ "operator=", "class_system_handle.html#a4ea9ba8379d6e82b144c36e4f4dc4b0b", null ],
    [ "setName", "class_system_handle.html#ab5d05c04ec8b4f8cc36abc70deba770d", null ],
    [ "setValue", "class_system_handle.html#aa7206ceb4d5ceaf67271edb1b12e135d", null ]
];