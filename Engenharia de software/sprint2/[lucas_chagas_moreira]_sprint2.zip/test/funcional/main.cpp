#include "funcionaltests.hpp"

int main()
{
    exponentialFuncionalTest();
    logisticalFuncionalTest();
    complexFuncionalTest();

    cout << "All functional tests succeed." << endl;

    return 0;
}